package com.example.agenda;

import android.content.Context;
import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import java.util.ArrayList;

public class ReminderAdapter extends ArrayAdapter<Reminder> {

    // 1. Interfaz para comunicar eventos de clic al MainMenu
    public interface OnTaskStateChangedListener {
        void onTaskStateChanged(int position, boolean isDone);
    }

    private OnTaskStateChangedListener mListener;

    public void setOnTaskStateChangedListener(OnTaskStateChangedListener listener) {
        this.mListener = listener;
    }

    public ReminderAdapter(Context context, ArrayList<Reminder> reminders) {
        super(context, 0, reminders);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item_reminder, parent, false);
        }

        Reminder currentReminder = getItem(position);

        TextView titleTextView = listItemView.findViewById(R.id.textview_title);
        CheckBox doneCheckBox = listItemView.findViewById(R.id.checkbox_done);

        if (currentReminder != null) {
            titleTextView.setText(currentReminder.getTitle());
            doneCheckBox.setChecked(currentReminder.isDone());

            // 2. Tachar el texto si la tarea está completada
            if (currentReminder.isDone()) {
                titleTextView.setPaintFlags(titleTextView.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                titleTextView.setAlpha(0.5f); // Atenuar el texto
            } else {
                titleTextView.setPaintFlags(titleTextView.getPaintFlags() & (~Paint.STRIKE_THRU_TEXT_FLAG));
                titleTextView.setAlpha(1.0f); // Restaurar opacidad normal
            }

            // 3. Configurar el listener para el CheckBox
            doneCheckBox.setOnClickListener(v -> {
                boolean isChecked = doneCheckBox.isChecked();
                if (mListener != null) {
                    // Avisar al MainMenu que el estado ha cambiado
                    mListener.onTaskStateChanged(position, isChecked);
                }
            });
        }

        return listItemView;
    }
}
