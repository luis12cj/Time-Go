package com.example.agenda;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.TextView; // <--- IMPORT AÑADIDO
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Objects;

public class MainActivity extends AppCompatActivity {

    private TextInputEditText editTextTitle, editTextDate, editTextTime, editTextDescription;
    private Calendar calendar;
    private Reminder reminderToEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // --- ¡CORRECCIÓN! Mover super.onCreate() al principio ---
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicialización del calendario
        calendar = Calendar.getInstance();

        // Enlazar vistas
        editTextTitle = findViewById(R.id.editTextTitle);
        editTextDate = findViewById(R.id.editTextDate);
        editTextTime = findViewById(R.id.editTextTime);
        editTextDescription = findViewById(R.id.descripcion);
        Button btnAdd = findViewById(R.id.btn_add);
        Button btnCancel = findViewById(R.id.btn_cancel);

        // --- Lógica para editar un recordatorio existente ---
        if (getIntent().hasExtra("REMINDER_TO_EDIT")) {
            // Usamos la comprobación de versión para seguridad
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                reminderToEdit = getIntent().getSerializableExtra("REMINDER_TO_EDIT", Reminder.class);
            } else {
                @SuppressWarnings("deprecation")
                Reminder temp = (Reminder) getIntent().getSerializableExtra("REMINDER_TO_EDIT");
                reminderToEdit = temp;
            }

            if (reminderToEdit != null) {
                editTextTitle.setText(reminderToEdit.getTitle());
                editTextDate.setText(reminderToEdit.getDate());
                editTextTime.setText(reminderToEdit.getTime());
                editTextDescription.setText(reminderToEdit.getDescription());
                // Cambiar el título de la pantalla a "Editar Recordatorio"
                ((TextView) findViewById(R.id.New_task)).setText(R.string.edit_task); // Usando recurso string
            }
        }

        // --- Configuración de Listeners ---
        editTextDate.setOnClickListener(v -> showDatePickerDialog());
        editTextTime.setOnClickListener(v -> showTimePickerDialog());
        btnCancel.setOnClickListener(v -> finish());
        btnAdd.setOnClickListener(v -> saveReminder());
    }

    private void showDatePickerDialog() {
        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (view, year, month, dayOfMonth) -> {
                    calendar.set(year, month, dayOfMonth);
                    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
                    editTextDate.setText(sdf.format(calendar.getTime()));
                },
                calendar.get(Calendar.YEAR),
                calendar.get(Calendar.MONTH),
                calendar.get(Calendar.DAY_OF_MONTH)
        );
        datePickerDialog.show();
    }

    private void showTimePickerDialog() {
        TimePickerDialog timePickerDialog = new TimePickerDialog(
                this,
                (view, hourOfDay, minute) -> {
                    calendar.set(Calendar.HOUR_OF_DAY, hourOfDay);
                    calendar.set(Calendar.MINUTE, minute);
                    SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
                    editTextTime.setText(sdf.format(calendar.getTime()));
                },
                calendar.get(Calendar.HOUR_OF_DAY),
                calendar.get(Calendar.MINUTE),
                false
        );
        timePickerDialog.show();
    }

    private void saveReminder() {
        String title = Objects.requireNonNull(editTextTitle.getText()).toString().trim();
        String date = Objects.requireNonNull(editTextDate.getText()).toString().trim();
        String time = Objects.requireNonNull(editTextTime.getText()).toString().trim();
        String description = Objects.requireNonNull(editTextDescription.getText()).toString().trim();

        if (TextUtils.isEmpty(title) || TextUtils.isEmpty(date) || TextUtils.isEmpty(time)) {
            Toast.makeText(this, "Título, fecha y hora son obligatorios", Toast.LENGTH_SHORT).show();
            return;
        }

        Reminder reminder;
        if (reminderToEdit != null) {
            // Actualizar recordatorio existente
            reminder = reminderToEdit;
            reminder.setTitle(title);
            reminder.setDate(date);
            reminder.setTime(time);
            reminder.setDescription(description);
        } else {
            // Crear nuevo recordatorio
            reminder = new Reminder(title, date, time, description);
        }

        Intent resultIntent = new Intent();
        resultIntent.putExtra("EXTRA_REMINDER", reminder);
        setResult(Activity.RESULT_OK, resultIntent);
        finish();
    }
}
