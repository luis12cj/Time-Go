package com.example.agenda

import android.app.Application
import com.google.android.material.color.DynamicColors

// Esta será la clase principal de tu aplicación
class AgendaApplication : Application() {
    override fun onCreate() {
        super.onCreate()

        // Esta línea es la que activa los colores dinámicos de Material You
        // en todas las actividades de tu app si el dispositivo es compatible.
        DynamicColors.applyToActivitiesIfAvailable(this)
    }
}
