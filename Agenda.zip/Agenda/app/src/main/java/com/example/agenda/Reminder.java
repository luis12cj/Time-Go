package com.example.agenda;

import java.io.Serializable;

public class Reminder implements Serializable {

    private String title;
    private String date;
    private String time;
    private String description;
    private boolean isDone;

    // --- Constructor ---
    public Reminder(String title, String date, String time, String description) {
        this.title = title;
        this.date = date;
        this.time = time;
        this.description = description;
        this.isDone = false; // Por defecto, una nueva tarea no está completada
    }

    // --- Getters (Métodos para OBTENER valores) ---
    public String getTitle() {
        return title;
    }

    public String getDate() {
        return date;
    }

    public String getTime() {
        return time;
    }

    public String getDescription() {
        return description;
    }

    public boolean isDone() {
        return isDone;
    }

    // --- ¡SETTERS AÑADIDOS! (Métodos para ESTABLECER/MODIFICAR valores) ---

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDone(boolean done) {
        isDone = done;
    }
}
