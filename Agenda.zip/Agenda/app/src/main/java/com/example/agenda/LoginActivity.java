package com.example.agenda;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;

import java.util.Objects;

public class LoginActivity extends AppCompatActivity {

    private TextInputEditText editTextUser, editTextPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 3. Enlazar las vistas con sus IDs del XML
        editTextUser = findViewById(R.id.editTextUser);
        editTextPassword = findViewById(R.id.editTextPassword);
        Button btnLogin = findViewById(R.id.btnLogin);

        // 4. Configurar el listener para el botón de login
        btnLogin.setOnClickListener(v -> {
            // Obtener el texto introducido por el usuario
            String usuario = Objects.requireNonNull(editTextUser.getText()).toString();
            String contrasena = Objects.requireNonNull(editTextPassword.getText()).toString();

            // 5. Validar las credenciales
            if (validarLogin(usuario, contrasena)) {
                // Si son correctas, iniciar MainMenu
                Intent intent = new Intent(LoginActivity.this, MainMenu.class);
                startActivity(intent);
                // Finalizar LoginActivity para que el usuario no pueda volver con el botón "atrás"
                finish();
            } else {
                // Si son incorrectas, mostrar un mensaje de error
                Toast.makeText(LoginActivity.this, "Usuario o contraseña incorrectos", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean validarLogin(String usuario, String contrasena) {
        // Comprobar que los campos no estén vacíos y que coincidan con las credenciales
        // 2. Definir credenciales fijas (para empezar)
        String USUARIO_CORRECTO = "Juanito Alcachofa";
        String CONTRASENA_CORRECTA = "2023905609";
        return !usuario.isEmpty() && !contrasena.isEmpty() &&
                usuario.equals(USUARIO_CORRECTO) && contrasena.equals(CONTRASENA_CORRECTA);
    }
}
