package com.example.agenda;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class ReminderDetailActivity extends AppCompatActivity {    private TextView tvTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reminder_detail);

        // Enlazar las vistas del layout con las variables
        tvTitle = findViewById(R.id.detailTextViewTitle);
        TextView tvDate = findViewById(R.id.detailTextViewDate);
        TextView tvTime = findViewById(R.id.detailTextViewTime);
        TextView tvDescription = findViewById(R.id.detailTextViewDescription);

        // Obtener el Intent que inició esta actividad
        Intent intent = getIntent();

        // Comprobar si el Intent contiene el objeto Reminder
        if (intent != null && intent.hasExtra("EXTRA_REMINDER")) {
            // Extraer el objeto Serializable
            Reminder reminder = (Reminder) intent.getSerializableExtra("EXTRA_REMINDER");

            // Rellenar las vistas con los datos del objeto
            if (reminder != null) {
                tvTitle.setText(reminder.getTitle());
                tvDate.setText(reminder.getDate());
                tvTime.setText(reminder.getTime());
                tvDescription.setText(reminder.getDescription());
            }
        } else {
            // Si algo falla, mostrar un error y cerrar
            Toast.makeText(this, "Error al cargar los datos del recordatorio", Toast.LENGTH_SHORT).show();
            finish();
        }
    }
}
