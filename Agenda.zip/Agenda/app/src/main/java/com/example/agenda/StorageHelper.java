package com.example.agenda;

import android.content.Context;
import android.content.SharedPreferences;

// Importaciones correctas
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken; // Asegúrate de que es esta importaciónimport java.lang.reflect.Type;

import java.lang.reflect.Type;
import java.util.ArrayList;

public class StorageHelper {

    private static final String PREFS_NAME = "ReminderPrefs";
    private static final String KEY_TASKS = "TaskList";

    // Método para guardar la lista de recordatorios
    public static void saveTasks(Context context, ArrayList<Reminder> taskList) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        Gson gson = new Gson();
        String json = gson.toJson(taskList);

        editor.putString(KEY_TASKS, json);
        editor.apply();
    }

    // Método para cargar la lista de recordatorios
    public static ArrayList<Reminder> loadTasks(Context context) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        Gson gson = new Gson();
        String json = sharedPreferences.getString(KEY_TASKS, null);

        // --- LÍNEA CORREGIDA ---
        // Aquí usamos la clase TypeToken que importamos directamente
        Type type = new TypeToken<ArrayList<Reminder>>() {}.getType();

        ArrayList<Reminder> taskList = gson.fromJson(json, type);

        if (taskList == null) {
            taskList = new ArrayList<>();
        }

        return taskList;
    }
}
