package com.example.agenda;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class MainMenu extends AppCompatActivity {

    private ArrayList<Reminder> taskList;
    private ReminderAdapter taskAdapter;
    private ListView listViewTasks; // <-- Variable declarada como campo de la clase
    private int selectedPosition = -1;

    // ... (Launchers y getReminderFromIntent se mantienen igual) ...
    // Launcher para AÑADIR un nuevo recordatorio
    private final ActivityResultLauncher<Intent> addTaskLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null && data.hasExtra("EXTRA_REMINDER")) {
                        Reminder newReminder = getReminderFromIntent(data); // Usamos un método ayudante
                        if (newReminder != null) {
                            taskList.add(newReminder);
                            taskAdapter.notifyDataSetChanged();
                            StorageHelper.saveTasks(this, taskList);
                        }
                    }
                }
            }
    );

    // Launcher para EDITAR un recordatorio existente
    private final ActivityResultLauncher<Intent> editTaskLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Intent data = result.getData();
                    if (data != null && data.hasExtra("EXTRA_REMINDER") && selectedPosition != -1) {
                        Reminder updatedReminder = getReminderFromIntent(data); // Usamos un método ayudante
                        if (updatedReminder != null) {
                            taskList.set(selectedPosition, updatedReminder);
                            taskAdapter.notifyDataSetChanged();
                            StorageHelper.saveTasks(this, taskList);
                        }
                    }
                }
                selectedPosition = -1; // Limpiar la posición seleccionada
            }
    );

    // --- MÉTODO AYUDANTE NUEVO PARA EXTRAER EL RECORDATORIO ---
    private Reminder getReminderFromIntent(Intent data) {
        // Comprueba la versión del SDK del dispositivo
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Si es Android 13 (Tiramisu) o superior, usa el método moderno
            return data.getSerializableExtra("EXTRA_REMINDER", Reminder.class);
        } else {
            // Para versiones más antiguas, usa el método obsoleto (con supresión de advertencia)
            @SuppressWarnings("deprecation")
            Reminder reminder = (Reminder) data.getSerializableExtra("EXTRA_REMINDER");
            return reminder;
        }
    }
    // --- FIN DEL MÉTODO AYUDANTE ---

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_menu);

        // Enlazar vistas
        listViewTasks = findViewById(R.id.listViewTasks);
        Button newTaskBtn = findViewById(R.id.new_taskbtn);

        // Cargar datos y configurar el adaptador
        taskList = StorageHelper.loadTasks(this);
        taskAdapter = new ReminderAdapter(this, taskList);

        // --- CÓDIGO CORREGIDO Y SIMPLIFICADO ---
        // Configura el listener UNA SOLA VEZ, usando la referencia al método.
        taskAdapter.setOnTaskStateChangedListener(this::handleToggleDone);
        // --- FIN DE LA CORRECCIÓN ---

        listViewTasks.setAdapter(taskAdapter);
        registerForContextMenu(listViewTasks);

        listViewTasks.setOnItemClickListener((parent, view, position, id) -> {
            Reminder clickedReminder = taskList.get(position);
            Intent intent = new Intent(MainMenu.this, ReminderDetailActivity.class);
            intent.putExtra("EXTRA_REMINDER", clickedReminder);
            startActivity(intent);
        });

        newTaskBtn.setOnClickListener(v -> {
            Intent intent = new Intent(MainMenu.this, MainActivity.class);
            addTaskLauncher.launch(intent);
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.list_item_menu, menu);
        AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) menuInfo;
        selectedPosition = info.position;
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        if (selectedPosition == -1) {
            return super.onContextItemSelected(item);
        }

        int itemId = item.getItemId();
        if (itemId == R.id.menu_edit) {
            handleEdit(selectedPosition);
            return true;
        } else if (itemId == R.id.menu_delete) {
            handleDelete(selectedPosition);
            return true;
        } else {
            return super.onContextItemSelected(item);
        }
    }

    private void handleToggleDone(int position, boolean isDone) {
        // Esta comprobación evita errores si la lista está desactualizada
        if (position >= 0 && position < taskList.size()) {
            Reminder reminder = taskList.get(position);
            reminder.setDone(isDone);
            taskAdapter.notifyDataSetChanged();
            StorageHelper.saveTasks(this, taskList);
        }
    }

    private void handleEdit(int position) {
        Reminder reminderToEdit = taskList.get(position);
        Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("REMINDER_TO_EDIT", reminderToEdit);
        editTaskLauncher.launch(intent);
    }

    private void handleDelete(int position) {
        new AlertDialog.Builder(this)
                .setTitle("Confirmar eliminación")
                .setMessage("¿Estás seguro de que deseas eliminar este recordatorio?")
                .setPositiveButton("Eliminar", (dialog, which) -> {
                    taskList.remove(position);
                    taskAdapter.notifyDataSetChanged();
                    StorageHelper.saveTasks(this, taskList);
                    Toast.makeText(this, "Recordatorio eliminado", Toast.LENGTH_SHORT).show();
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }
}
