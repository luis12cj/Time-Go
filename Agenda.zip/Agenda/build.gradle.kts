// Top-level build file where you can add configuration options common to all sub-projects/modules.
plugins {
    // --- ¡LA CORRECCIÓN MÁS IMPORTANTE ESTÁ AQUÍ! ---
    // Actualiza la versión del Android Gradle Plugin
    id("com.android.application") version "8.13.0" apply false
    alias(libs.plugins.kotlin.android) apply false
}
